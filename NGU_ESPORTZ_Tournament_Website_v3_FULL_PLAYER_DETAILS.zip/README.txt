NGU ESPORTZ V3
- Solo/Duo/Squad registration
- Duo stores 2 player names + UIDs
- Squad stores 4 player names + UIDs
- Admin sees ALL player details in one registration row
- Unlimited editable prize rows
- Registration data stored in data.json
- Admin default login: admin / ngu123 (change environment variables for production)
- Demo registration only; connect real payment gateway before accepting payments.
